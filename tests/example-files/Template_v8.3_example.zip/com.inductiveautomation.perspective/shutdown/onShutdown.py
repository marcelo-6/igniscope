def onShutdown(session):
	pass