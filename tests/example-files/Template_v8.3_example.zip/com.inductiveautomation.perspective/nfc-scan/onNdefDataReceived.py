def onNdefDataReceived(session, data, context):
	pass