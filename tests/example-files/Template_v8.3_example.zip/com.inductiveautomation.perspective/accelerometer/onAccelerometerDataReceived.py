def onAccelerometerDataReceived(session, data, context):
	pass