def onKeyEvent(page, event):
	pass