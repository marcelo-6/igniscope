def onStartup(session):
	pass