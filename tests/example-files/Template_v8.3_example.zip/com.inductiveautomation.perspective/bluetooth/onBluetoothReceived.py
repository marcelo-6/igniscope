def onBluetoothReceived(session, data):
	pass