def onAuthChallengeCompleted(session, payload, result):
	pass