def onPageStartup(page):
	pass