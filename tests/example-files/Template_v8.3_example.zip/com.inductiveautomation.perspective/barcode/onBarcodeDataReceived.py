def onBarcodeDataReceived(session, data, context):
	pass