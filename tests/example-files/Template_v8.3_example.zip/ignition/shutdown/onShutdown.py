def onShutdown():
	pass