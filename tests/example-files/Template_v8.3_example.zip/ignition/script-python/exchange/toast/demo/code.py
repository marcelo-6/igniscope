from exchange.toast.util.util import BasicContainer

class MessageTypes(BasicContainer):
	"""Demo Message Type class for using different kinds of toast notifications"""
	ROOT = 'Exchange/Toast/Message/{0}'
	
	CONTENT = {
		'basic': {'name': 'Basic', 'view': 'Basic'}
		, 'expanding': {'name': 'Expanding', 'view': 'Expanding'}
		, 'navigation': {'name': 'Navigation', 'view': 'Navigation'}
		, 'open': {'name': 'Open', 'view': 'Open'}
	}
	
	@classmethod
	def getDropdown(cls):
		"""Get the dropdown options for message types in the demo"""
		option = lambda x: {'label': x.get('name'), 'value': cls.ROOT.format(x.get('view'))}
		return [option(item) for item in cls.getAvailable().values()]
	
def getDemoToastValues(messageType):
	"""Get the args to pass into toastNotification function for the demo page"""
	value = messageType.lower()
	content = {
		'basic': {}
		, 'expanding': {
			'content': 'Demo expanding toast message'
		}
		, 'navigation': {
			'navigateTo': {
				'url': 'https://www.google.com/'
				, 'newTab': True
			}
		}
		, 'open-dock': {
			'openItem': {
				'params': {'id': 'demo_dock'}
				, 'type': 'dock'
			}
		}
		, 'open-popup': {
			'openItem': {
				'params': {'id': 'demo_popup', 'view': 'Exchange/Toast/Demo/Framework/Popup'}
				, 'type': 'popup'
			}
		}
	}
	return content.get(messageType.lower(), {})