def run():
	project = system.project.getProjectName()
	path = "New Folder/Event Stream - http"
	log = system.util.getLogger("marcelo.event.test")
	log.info("{}".format(system.eventstream.getDiagnostics(project, path)))
	log.info("{}".format(system.eventstream.listEventStreams(project)))
	# system.eventstream.publishEvent(project, path, message, acknowledge, gatewayName)