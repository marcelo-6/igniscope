def handleScheduleEvent():
	pass