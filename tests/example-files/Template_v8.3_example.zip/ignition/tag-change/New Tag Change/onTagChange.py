def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	pass