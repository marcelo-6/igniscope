def handleTimerEvent():
	pass