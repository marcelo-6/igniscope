def onStartup():
	pass