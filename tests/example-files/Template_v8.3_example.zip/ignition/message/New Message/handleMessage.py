def handleMessage(payload):
	test.run()